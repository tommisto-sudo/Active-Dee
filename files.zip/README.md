# Backend สำหรับฟอร์ม Contact (เวอร์ชัน PHP)

ใช้แทนเวอร์ชัน Python/Flask เดิม สำหรับ hosting ที่มีแต่ PHP + MySQL + SMTP

## ไฟล์ในชุดนี้

| ไฟล์ | หน้าที่ |
|---|---|
| `contact.php` | endpoint หลัก รับข้อมูลจากฟอร์ม, บันทึกลง DB, ส่งอีเมล |
| `config.php` | เก็บค่า DB และ SMTP — **ต้องแก้เป็นของจริงก่อนใช้** |
| `SimpleSmtpMailer.php` | คลาสส่งอีเมลผ่าน SMTP เขียนด้วย PHP ล้วน ไม่ต้องพึ่ง Composer/library ภายนอก |
| `schema.sql` | คำสั่งสร้างฐานข้อมูลและตาราง `contacts` |

## วิธีติดตั้ง

1. **สร้างฐานข้อมูล** — รันไฟล์ SQL ครั้งเดียว:
   ```bash
   mysql -u root -p < schema.sql
   ```
   หรือ import ผ่าน phpMyAdmin ก็ได้

2. **แก้ `config.php`** ให้เป็นค่าจริง:
   - `DB_HOST`, `DB_NAME`, `DB_USER`, `DB_PASS` — ข้อมูลเชื่อมต่อฐานข้อมูลที่ hosting ให้มา
   - `SMTP_HOST`, `SMTP_PORT`, `SMTP_USER`, `SMTP_PASSWORD` — ข้อมูล SMTP ที่ hosting ให้มา (หรือของ Gmail/Office365 ก็ได้)
   - `CONTACT_RECEIVER_EMAIL` — อีเมลที่จะให้ข้อความจากฟอร์มส่งไปถึง

3. **อัปโหลดไฟล์ทั้งหมด** (`contact.php`, `config.php`, `SimpleSmtpMailer.php`) ขึ้นไปไว้โฟลเดอร์เดียวกับ `contactus.html` บน server (หรือจะแยกโฟลเดอร์ก็ได้ แค่แก้ path ใน `contactus.html` ตามข้อ 4)

4. **ตรวจสอบใน `contactus.html`** — มีบรรทัด
   ```js
   const CONTACT_API_URL = "contact.php";
   ```
   ถ้าวาง `contact.php` ไว้คนละโฟลเดอร์กับหน้าเว็บ ให้แก้ path ตรงนี้ให้ตรงกับตำแหน่งจริง

5. เปิดหน้า `contactus.html` ผ่าน URL จริงของเว็บ (ต้องเปิดผ่าน `http://` หรือ `https://` เท่านั้น — เปิดไฟล์ตรง ๆ แบบ `file://` จะยิง fetch ไป PHP ไม่ได้) แล้วลองกรอกฟอร์มทดสอบ

## หมายเหตุเรื่อง SMTP

- ถ้า hosting ให้ SMTP มาเอง (ไม่ใช่ Gmail) มักจะเป็น `mail.yourdomain.co.th` พอร์ต `587` (STARTTLS) หรือ `465` (SSL) — สอบถามผู้ดูแล hosting เพื่อขอค่าที่ถูกต้อง ถ้าเป็นพอร์ต 465 (SSL ตรง ไม่ใช่ STARTTLS) ต้องแก้ `SimpleSmtpMailer.php` ให้เชื่อมต่อผ่าน `ssl://` ตั้งแต่ต้น แจ้งมาได้ถ้าต้องการเวอร์ชันนั้นเพิ่ม
- ถ้าใช้ Gmail ต้องเปิด 2-Step Verification แล้วสร้าง **App Password** ที่ `myaccount.google.com/apppasswords` — ใช้ App Password แทนรหัสผ่านจริงใน `SMTP_PASSWORD`
- ถ้าอีเมลส่งไม่ออก ข้อมูลฟอร์มจะยังถูกบันทึกลงฐานข้อมูลตามปกติ (ไม่หาย) — ให้เช็ก error log ของ PHP บน server เพื่อดูสาเหตุ

## เกี่ยวกับ POP3

ระบบนี้ใช้ **SMTP สำหรับส่งอีเมลออกเท่านั้น** — POP3 ใช้สำหรับ "รับ/อ่าน" อีเมลเข้ากล่องจดหมาย (เช่น ถ้าอยากให้เว็บไปเช็คว่ามีคนตอบกลับอีเมลไหม) ซึ่งเป็นคนละงานกับฟอร์ม contact ที่มีแค่ "ส่งออก" ทางเดียว ตอนนี้ยังไม่จำเป็นต้องใช้ POP3 — ถ้าต้องการให้ระบบดึงอีเมลตอบกลับมาแสดงในเว็บด้วย บอกได้ครับ จะทำเพิ่มให้

## อัปเกรดเป็น PHPMailer (ถ้าต้องการ)

`SimpleSmtpMailer.php` เป็นเวอร์ชันเบาที่เขียนเองเพื่อไม่ต้องพึ่ง Composer ใช้งานได้กับ SMTP ทั่วไป
แต่ถ้า server มี Composer และต้องการความเสถียรสูงสุด (รองรับไฟล์แนบ, edge case ของ SMTP หลากหลายกว่า)
สามารถติดตั้ง PHPMailer แทนได้:

```bash
composer require phpmailer/phpmailer
```

แล้วแก้ใน `contact.php` ส่วนที่เรียก `SimpleSmtpMailer` ให้เปลี่ยนไปใช้ `PHPMailer\PHPMailer\PHPMailer` แทน — โครงสร้างการเรียก (host, port, user, password, from, to, subject, body) เหมือนกัน
